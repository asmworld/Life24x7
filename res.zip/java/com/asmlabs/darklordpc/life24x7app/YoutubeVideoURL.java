package com.asmlabs.darklordpc.life24x7app;

/**
 * Created by darklordpc on 21/09/2017.
 */

public class YoutubeVideoURL {
    String videourl;

    public YoutubeVideoURL() {
    }

    public YoutubeVideoURL(String videourl) {
        this.videourl = videourl;
    }

    public String getVideourl() {
        return videourl;
    }

    public void setVideourl(String videourl) {
        this.videourl = videourl;
    }
}
