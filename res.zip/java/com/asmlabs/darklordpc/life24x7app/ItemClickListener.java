package com.asmlabs.darklordpc.life24x7app;

import android.view.View;

public interface ItemClickListener {

    void onClick(View view, int position, boolean isLongClick);
}